let hours_worked = [ 21; 21; 18; 14 ]
